# Example file for Advanced Python: Language Features by Joe Marini
# Demonstrate the use of lambda functions


# TODO: define a function that takes variable arguments
def addition():
    pass


# TODO: pass different arguments
print(addition())

# TODO: pass an existing list
